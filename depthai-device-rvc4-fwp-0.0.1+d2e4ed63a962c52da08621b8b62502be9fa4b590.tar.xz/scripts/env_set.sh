### Use the following settings, or create a new a configuration file,
# e.g. env_set.sh with contents below.

# Check if this is RVC4 /sys/module/qcom_ipcc'
if [ -d /sys/module/qcom_ipcc ]; then
    echo "RVC4"
    export RVC4=1
else
    echo "RVC3"
    export RVC3=1
fi

# If RVC4 set ADSP_LIBRARY_PATH and exit
if [ -n "$RVC4" ]; then
    export ADSP_LIBRARY_PATH='/usr/lib;/dsp;/opt/qcom/aistack/qairt/2.23.0.24.06.24/lib/hexagon-v73/unsigned/'
    export ASAN_OPTIONS=new_delete_type_mismatch=0:abort_on_error=1
    return
fi

rm -rf ~/.cache/
if [ -f /sys/devices/platform/soc/soc\:vpusmm/fwname ]; then
    echo "" > /sys/devices/platform/soc/soc\:vpusmm/fwname;
fi

source /opt/openvino/setupvars.sh
export VPU_FIRMWARE_FILE=""
export SIPP_FIRST_SHAVE=2
export ENABLE_GVA_FEATURES=compact-meta
STEPPING=`cat /sys/firmware/devicetree/base/soc/version-info/stepping`
if [[ ${STEPPING} =~ 'B0' ]]
then
    source /opt/intel/codec-unify/unify.sh
    rmmod hantro
    modprobe hantro
else
    rmmod hantrodriver
    modprobe hantrodriver
fi

modprobe kmb_flash
modprobe kmb_lens
modprobe kmb_cam
modprobe pwm_keembay
