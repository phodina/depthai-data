#!/bin/bash

modprobe kmb_flash
modprobe kmb_lens
modprobe kmb_cam
modprobe pwm_keembay
