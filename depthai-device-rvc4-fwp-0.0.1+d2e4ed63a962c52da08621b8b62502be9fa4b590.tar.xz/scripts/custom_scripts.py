try:
    import os
    import subprocess
    import pathlib
    current_dir = pathlib.Path(__file__).parent.absolute()
except Exception as e: 
    print(e)
    raise e

def shell_source(script):
    """Get the enviroment that is created by sourcing the script"""
    pipe = subprocess.Popen(". %s > /dev/null; env" % script, stdout=subprocess.PIPE, shell=True)
    output = pipe.communicate()[0]
    env = dict((line.split("=", 1) for line in output.decode().splitlines()))
    return env

def on_start():
    print("on_start")
    subprocess.call(['bash', str(current_dir / './modprobe.sh')])
    model = ''
    try:
        with open('/sys/firmware/devicetree/base/model') as f:
            model = f.readlines()[0].split('\x00')[0]
    except Exception as ex:
        pass

    if model == 'NG3398C_RA_R0M0E0':
        subprocess.call(['bash', str(current_dir / './NG3398C_RA_R0M0E0.sh')])

    return shell_source(str(current_dir / './env_set.sh'))

def on_stop():
    print("on_stop")
    pass

def on_create():
    print("on_create")
    pass

def on_destroy():
    print("on_destroy")
    pass
