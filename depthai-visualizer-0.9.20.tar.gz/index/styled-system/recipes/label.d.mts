/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { Pretty } from '../types/helpers.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

interface LabelVariant {
  
}

type LabelVariantMap = {
  [key in keyof LabelVariant]: Array<LabelVariant[key]>
}

export type LabelVariantProps = {
  [key in keyof LabelVariant]?: ConditionalValue<LabelVariant[key]>
}

export interface LabelRecipe {
  __type: LabelVariantProps
  (props?: LabelVariantProps): string
  raw: (props?: LabelVariantProps) => LabelVariantProps
  variantMap: LabelVariantMap
  variantKeys: Array<keyof LabelVariant>
  splitVariantProps<Props extends LabelVariantProps>(props: Props): [LabelVariantProps, Pretty<DistributiveOmit<Props, keyof LabelVariantProps>>]
}

/** Styles for the Label component */
export declare const label: LabelRecipe