/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { Pretty } from '../types/helpers.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

interface TypographyTableVariant {
  
}

type TypographyTableVariantMap = {
  [key in keyof TypographyTableVariant]: Array<TypographyTableVariant[key]>
}

export type TypographyTableVariantProps = {
  [key in keyof TypographyTableVariant]?: ConditionalValue<TypographyTableVariant[key]>
}

export interface TypographyTableRecipe {
  __type: TypographyTableVariantProps
  (props?: TypographyTableVariantProps): string
  raw: (props?: TypographyTableVariantProps) => TypographyTableVariantProps
  variantMap: TypographyTableVariantMap
  variantKeys: Array<keyof TypographyTableVariant>
  splitVariantProps<Props extends TypographyTableVariantProps>(props: Props): [TypographyTableVariantProps, Pretty<DistributiveOmit<Props, keyof TypographyTableVariantProps>>]
}

/** Typography - table style */
export declare const typographyTable: TypographyTableRecipe