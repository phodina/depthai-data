/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { Pretty } from '../types/helpers.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

interface ProgressVariant {
  
}

type ProgressVariantMap = {
  [key in keyof ProgressVariant]: Array<ProgressVariant[key]>
}

export type ProgressVariantProps = {
  [key in keyof ProgressVariant]?: ConditionalValue<ProgressVariant[key]>
}

export interface ProgressRecipe {
  __type: ProgressVariantProps
  (props?: ProgressVariantProps): Pretty<Record<"root" | "indicator", string>>
  raw: (props?: ProgressVariantProps) => ProgressVariantProps
  variantMap: ProgressVariantMap
  variantKeys: Array<keyof ProgressVariant>
  splitVariantProps<Props extends ProgressVariantProps>(props: Props): [ProgressVariantProps, Pretty<DistributiveOmit<Props, keyof ProgressVariantProps>>]
}

/** Styles for the Progress component */
export declare const progress: ProgressRecipe