/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { Pretty } from '../types/helpers.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

interface SwitchRecipeVariant {
  
}

type SwitchRecipeVariantMap = {
  [key in keyof SwitchRecipeVariant]: Array<SwitchRecipeVariant[key]>
}

export type SwitchRecipeVariantProps = {
  [key in keyof SwitchRecipeVariant]?: ConditionalValue<SwitchRecipeVariant[key]>
}

export interface SwitchRecipeRecipe {
  __type: SwitchRecipeVariantProps
  (props?: SwitchRecipeVariantProps): Pretty<Record<"root" | "thumb", string>>
  raw: (props?: SwitchRecipeVariantProps) => SwitchRecipeVariantProps
  variantMap: SwitchRecipeVariantMap
  variantKeys: Array<keyof SwitchRecipeVariant>
  splitVariantProps<Props extends SwitchRecipeVariantProps>(props: Props): [SwitchRecipeVariantProps, Pretty<DistributiveOmit<Props, keyof SwitchRecipeVariantProps>>]
}

/** Styles for the Switch component */
export declare const switchRecipe: SwitchRecipeRecipe