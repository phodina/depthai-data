/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { Pretty } from '../types/helpers.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

interface RadioGroupVariant {
  
}

type RadioGroupVariantMap = {
  [key in keyof RadioGroupVariant]: Array<RadioGroupVariant[key]>
}

export type RadioGroupVariantProps = {
  [key in keyof RadioGroupVariant]?: ConditionalValue<RadioGroupVariant[key]>
}

export interface RadioGroupRecipe {
  __type: RadioGroupVariantProps
  (props?: RadioGroupVariantProps): Pretty<Record<"root" | "item" | "indicator" | "icon", string>>
  raw: (props?: RadioGroupVariantProps) => RadioGroupVariantProps
  variantMap: RadioGroupVariantMap
  variantKeys: Array<keyof RadioGroupVariant>
  splitVariantProps<Props extends RadioGroupVariantProps>(props: Props): [RadioGroupVariantProps, Pretty<DistributiveOmit<Props, keyof RadioGroupVariantProps>>]
}

/** Styles for the RadioGroup component */
export declare const radioGroup: RadioGroupRecipe