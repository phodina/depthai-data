/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { Pretty } from '../types/helpers.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

interface TypographyTableContainerVariant {
  
}

type TypographyTableContainerVariantMap = {
  [key in keyof TypographyTableContainerVariant]: Array<TypographyTableContainerVariant[key]>
}

export type TypographyTableContainerVariantProps = {
  [key in keyof TypographyTableContainerVariant]?: ConditionalValue<TypographyTableContainerVariant[key]>
}

export interface TypographyTableContainerRecipe {
  __type: TypographyTableContainerVariantProps
  (props?: TypographyTableContainerVariantProps): string
  raw: (props?: TypographyTableContainerVariantProps) => TypographyTableContainerVariantProps
  variantMap: TypographyTableContainerVariantMap
  variantKeys: Array<keyof TypographyTableContainerVariant>
  splitVariantProps<Props extends TypographyTableContainerVariantProps>(props: Props): [TypographyTableContainerVariantProps, Pretty<DistributiveOmit<Props, keyof TypographyTableContainerVariantProps>>]
}

/** Typography - table container style */
export declare const typographyTableContainer: TypographyTableContainerRecipe