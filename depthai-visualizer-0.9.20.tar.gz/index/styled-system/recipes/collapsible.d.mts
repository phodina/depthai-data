/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { Pretty } from '../types/helpers.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

interface CollapsibleVariant {
  
}

type CollapsibleVariantMap = {
  [key in keyof CollapsibleVariant]: Array<CollapsibleVariant[key]>
}

export type CollapsibleVariantProps = {
  [key in keyof CollapsibleVariant]?: ConditionalValue<CollapsibleVariant[key]>
}

export interface CollapsibleRecipe {
  __type: CollapsibleVariantProps
  (props?: CollapsibleVariantProps): Pretty<Record<"root" | "trigger" | "content", string>>
  raw: (props?: CollapsibleVariantProps) => CollapsibleVariantProps
  variantMap: CollapsibleVariantMap
  variantKeys: Array<keyof CollapsibleVariant>
  splitVariantProps<Props extends CollapsibleVariantProps>(props: Props): [CollapsibleVariantProps, Pretty<DistributiveOmit<Props, keyof CollapsibleVariantProps>>]
}

/** Styles for the Collapsible component */
export declare const collapsible: CollapsibleRecipe