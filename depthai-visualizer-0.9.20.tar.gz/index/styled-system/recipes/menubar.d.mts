/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { Pretty } from '../types/helpers.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

interface MenubarVariant {
  
}

type MenubarVariantMap = {
  [key in keyof MenubarVariant]: Array<MenubarVariant[key]>
}

export type MenubarVariantProps = {
  [key in keyof MenubarVariant]?: ConditionalValue<MenubarVariant[key]>
}

export interface MenubarRecipe {
  __type: MenubarVariantProps
  (props?: MenubarVariantProps): Pretty<Record<"root" | "menu" | "group" | "portal" | "sub" | "radioGroup" | "trigger" | "subTrigger" | "subContent" | "content" | "item" | "checkboxItem" | "radioItem" | "itemIndicator" | "label" | "separator" | "shortcut", string>>
  raw: (props?: MenubarVariantProps) => MenubarVariantProps
  variantMap: MenubarVariantMap
  variantKeys: Array<keyof MenubarVariant>
  splitVariantProps<Props extends MenubarVariantProps>(props: Props): [MenubarVariantProps, Pretty<DistributiveOmit<Props, keyof MenubarVariantProps>>]
}

/** Styles for the Menubar component */
export declare const menubar: MenubarRecipe