/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */const ne=Symbol("Comlink.proxy"),Pe=Symbol("Comlink.endpoint"),Ue=Symbol("Comlink.releaseProxy"),$=Symbol("Comlink.finalizer"),V=Symbol("Comlink.thrown"),ae=e=>typeof e=="object"&&e!==null||typeof e=="function",xe={canHandle:e=>ae(e)&&e[ne],serialize(e){const{port1:t,port2:r}=new MessageChannel;return j(e,t),[r,[r]]},deserialize(e){return e.start(),Se(e)}},we={canHandle:e=>ae(e)&&V in e,serialize({value:e}){let t;return e instanceof Error?t={isError:!0,value:{message:e.message,name:e.name,stack:e.stack}}:t={isError:!1,value:e},[t,[]]},deserialize(e){throw e.isError?Object.assign(new Error(e.value.message),e.value):e.value}},ie=new Map([["proxy",xe],["throw",we]]);function Be(e,t){for(const r of e)if(t===r||r==="*"||r instanceof RegExp&&r.test(t))return!0;return!1}function j(e,t=globalThis,r=["*"]){t.addEventListener("message",function m(s){if(!s||!s.data)return;if(!Be(r,s.origin)){console.warn(`Invalid origin '${s.origin}' for comlink proxy`);return}const{id:o,type:p,path:u}=Object.assign({path:[]},s.data),c=(s.data.argumentList||[]).map(C);let l;try{const f=u.slice(0,-1).reduce((i,a)=>i[a],e),n=u.reduce((i,a)=>i[a],e);switch(p){case"GET":l=n;break;case"SET":f[u.slice(-1)[0]]=C(s.data.value),l=!0;break;case"APPLY":l=n.apply(f,c);break;case"CONSTRUCT":{const i=new n(...c);l=Oe(i)}break;case"ENDPOINT":{const{port1:i,port2:a}=new MessageChannel;j(e,a),l=Ae(i,[i])}break;case"RELEASE":l=void 0;break;default:return}}catch(f){l={value:f,[V]:0}}Promise.resolve(l).catch(f=>({value:f,[V]:0})).then(f=>{const[n,i]=H(f);t.postMessage(Object.assign(Object.assign({},n),{id:o}),i),p==="RELEASE"&&(t.removeEventListener("message",m),se(t),$ in e&&typeof e[$]=="function"&&e[$]())}).catch(f=>{const[n,i]=H({value:new TypeError("Unserializable return value"),[V]:0});t.postMessage(Object.assign(Object.assign({},n),{id:o}),i)})}),t.start&&t.start()}function Ee(e){return e.constructor.name==="MessagePort"}function se(e){Ee(e)&&e.close()}function Se(e,t){const r=new Map;return e.addEventListener("message",function(s){const{data:o}=s;if(!o||!o.id)return;const p=r.get(o.id);if(p)try{p(o)}finally{r.delete(o.id)}}),q(e,r,[],t)}function L(e){if(e)throw new Error("Proxy has been released and is not useable")}function oe(e){return z(e,new Map,{type:"RELEASE"}).then(()=>{se(e)})}const Y=new WeakMap,W="FinalizationRegistry"in globalThis&&new FinalizationRegistry(e=>{const t=(Y.get(e)||0)-1;Y.set(e,t),t===0&&oe(e)});function Ie(e,t){const r=(Y.get(t)||0)+1;Y.set(t,r),W&&W.register(e,t,e)}function ve(e){W&&W.unregister(e)}function q(e,t,r=[],m=function(){}){let s=!1;const o=new Proxy(m,{get(p,u){if(L(s),u===Ue)return()=>{ve(o),oe(e),t.clear(),s=!0};if(u==="then"){if(r.length===0)return{then:()=>o};const c=z(e,t,{type:"GET",path:r.map(l=>l.toString())}).then(C);return c.then.bind(c)}return q(e,t,[...r,u])},set(p,u,c){L(s);const[l,f]=H(c);return z(e,t,{type:"SET",path:[...r,u].map(n=>n.toString()),value:l},f).then(C)},apply(p,u,c){L(s);const l=r[r.length-1];if(l===Pe)return z(e,t,{type:"ENDPOINT"}).then(C);if(l==="bind")return q(e,t,r.slice(0,-1));const[f,n]=ee(c);return z(e,t,{type:"APPLY",path:r.map(i=>i.toString()),argumentList:f},n).then(C)},construct(p,u){L(s);const[c,l]=ee(u);return z(e,t,{type:"CONSTRUCT",path:r.map(f=>f.toString()),argumentList:c},l).then(C)}});return Ie(o,e),o}function Fe(e){return Array.prototype.concat.apply([],e)}function ee(e){const t=e.map(H);return[t.map(r=>r[0]),Fe(t.map(r=>r[1]))]}const ue=new WeakMap;function Ae(e,t){return ue.set(e,t),e}function Oe(e){return Object.assign(e,{[ne]:!0})}function H(e){for(const[t,r]of ie)if(r.canHandle(e)){const[m,s]=r.serialize(e);return[{type:"HANDLER",name:t,value:m},s]}return[{type:"RAW",value:e},ue.get(e)||[]]}function C(e){switch(e.type){case"HANDLER":return ie.get(e.name).deserialize(e.value);case"RAW":return e.value}}function z(e,t,r,m){return new Promise(s=>{const o=Math.trunc(Math.random()*Number.MAX_SAFE_INTEGER).toString();t.set(o,s),e.start&&e.start(),e.postMessage(Object.assign({id:o},r),m)})}function te(e,t,r,m,s,o){const p=t*r,u=p,c=p+p/4,l=o.byteLength/16,f=new ArrayBuffer(o.byteLength),n=new DataView(f),i=new DataView(o.buffer);for(let a=0;a<l;a++){const y=a%m,P=Math.floor(a/m),w=Math.round(y*(t/m)),S=Math.round(P*(r/s));if(w>=t||S>=r)continue;const B=S*t+w,M=Math.floor(S/2)*(t/2)+Math.floor(w/2),g=e[B]??0,d=(e[u+M]??128)-128,h=(e[c+M]??128)-128;let _=g+1.402*h,E=g-.344136*d-.714136*h,v=g+1.772*d;_=Math.min(255,Math.max(0,_)),E=Math.min(255,Math.max(0,E)),v=Math.min(255,Math.max(0,v));const U=a*16;n.setFloat32(U,i.getFloat32(U,!0),!0),n.setFloat32(U+4,i.getFloat32(U+4,!0),!0),n.setFloat32(U+8,i.getFloat32(U+8,!0),!0),n.setUint8(U+12,_),n.setUint8(U+13,E),n.setUint8(U+14,v),n.setUint8(U+15,255)}return new Uint8Array(f)}function re(e,t,r,m,s,o,p){const u=t*r,c=new Float32Array(u*3);for(let i=0;i<r;i++)for(let a=0;a<t;a++){const y=i*t+a,P=e[y]??0;let w=0,S=0,B=0;const g=P*1;g>0&&m!==0&&s!==0&&(w=(a-o)*g/m,S=(p-i)*g/s,B=g);const d=y*3;c[d]=w,c[d+1]=S,c[d+2]=B}const l=new ArrayBuffer(u*16),f=new DataView(l),n=new Uint8Array(c.buffer);for(let i=0;i<u;i++){const a=i*12,y=i*16;for(let P=0;P<12;++P)f.setUint8(y+P,n[a+P]);f.setUint8(y+12,0),f.setUint8(y+13,0),f.setUint8(y+14,0),f.setUint8(y+15,255)}return new Uint8Array(l)}const le=128,Ce=16,Me=`
struct Intrinsics {
  fx: f32,
  fy: f32,
  cx: f32,
  cy: f32,
  depthScale: f32,
  depthWidth: f32,
  depthHeight: f32,
  i420Width: f32,
  i420Height: f32,
  numFrames_f: f32,
  bytesPerI420Frame_f: f32,
};

struct OutputPointData {
  x: f32,
  y: f32,
  z: f32,
  color: u32,
};

@group(0) @binding(0) var<storage, read> depthBuffer: array<u32>;
@group(0) @binding(1) var<storage, read> intrinsics: Intrinsics;
@group(0) @binding(2) var<storage, read_write> xyzColorBuffer: array<OutputPointData>;
@group(0) @binding(3) var<storage, read> i420Buffer: array<u32>;

fn getI420Byte(byteIndexWithinFrame: u32, frameOffsetElements: u32, bufferLengthElements: u32) -> u32 {
  let globalByteIndex = (frameOffsetElements * 4u) + byteIndexWithinFrame;
  let elementIndex = globalByteIndex / 4u;
  let offsetInElement = globalByteIndex % 4u;
  if (elementIndex >= bufferLengthElements) {
    return 0u;
  }
  let packedValue = i420Buffer[elementIndex];
  return (packedValue >> (offsetInElement * 8u)) & 0xFFu;
}

@compute @workgroup_size(${le}, 1, 1)
fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
  let pixel_idx_in_frame = global_id.x;
  let frame_idx = global_id.y;
  let depthWidth = u32(intrinsics.depthWidth);
  let depthHeight = u32(intrinsics.depthHeight);
  let i420WidthU = u32(intrinsics.i420Width);
  let i420HeightU = u32(intrinsics.i420Height);
  let numFrames = u32(intrinsics.numFrames_f);
  let bytesPerI420Frame = u32(intrinsics.bytesPerI420Frame_f);
  let numPixelsPerFrame = depthWidth * depthHeight;
  if (pixel_idx_in_frame >= numPixelsPerFrame || frame_idx >= numFrames || depthWidth == 0u || depthHeight == 0u) {
    return;
  }
  let global_output_idx = (frame_idx * numPixelsPerFrame) + pixel_idx_in_frame;
  let depth_elements_per_frame = (numPixelsPerFrame + 1u) / 2u;
  let depth_frame_offset = frame_idx * depth_elements_per_frame;
  let i420AlignedStrideBytes = (bytesPerI420Frame + 3u) / 4u * 4u;
  let i420_elements_per_frame_aligned = i420AlignedStrideBytes / 4u;
  let i420_frame_offset = frame_idx * i420_elements_per_frame_aligned;
  let depthIndex32_within_frame = pixel_idx_in_frame / 2u;
  let packedDepthU32_idx = depth_frame_offset + depthIndex32_within_frame;
  if (packedDepthU32_idx >= arrayLength(&depthBuffer)) {
    return;
  }
  let packedDepthU32 = depthBuffer[packedDepthU32_idx];
  var rawDepthU16: u32;
  if (pixel_idx_in_frame % 2u == 0u) {
    rawDepthU16 = packedDepthU32 & 0xFFFFu;
  } else {
    rawDepthU16 = (packedDepthU32 >> 16u) & 0xFFFFu;
  }
  let u = f32(pixel_idx_in_frame % depthWidth);
  let v = f32(pixel_idx_in_frame / depthWidth);
  var outputPoint: OutputPointData;
  outputPoint.x = 0.0;
  outputPoint.y = 0.0;
  outputPoint.z = 0.0;
  outputPoint.color = 0xFF000000u;
  let fx = intrinsics.fx;
  let fy = intrinsics.fy;
  let cx = intrinsics.cx;
  let cy = intrinsics.cy;
  let depthScale = intrinsics.depthScale;
  if (rawDepthU16 > 0u && fx != 0.0 && fy != 0.0 && depthScale > 0.0) {
    let z = f32(rawDepthU16) * depthScale;
    outputPoint.x = (u - cx) * z / fx;
    outputPoint.y = (v - cy) * z / fy;
    outputPoint.z = z;
    if (i420WidthU > 0u && i420HeightU > 0u && bytesPerI420Frame > 0u) {
      let i420X = min(i420WidthU - 1u, u32(floor(u * (intrinsics.i420Width / intrinsics.depthWidth))));
      let i420Y = min(i420HeightU - 1u, u32(floor(v * (intrinsics.i420Height / intrinsics.depthHeight))));
      let frameSizeY = i420WidthU * i420HeightU;
      let uvWidth = (i420WidthU + 1u) / 2u;
      let uvHeight = (i420HeightU + 1u) / 2u;
      let frameSizeUV = uvWidth * uvHeight;
      let uOffsetBytes = frameSizeY;
      let vOffsetBytes = frameSizeY + frameSizeUV;
      let yIndexBytes = i420Y * i420WidthU + i420X;
      let uvX = i420X / 2u;
      let uvY = i420Y / 2u;
      let uvIndexBytes = uvY * uvWidth + uvX;
      let uIndexBytes = uOffsetBytes + uvIndexBytes;
      let vIndexBytes = vOffsetBytes + uvIndexBytes;
      let i420BufferTotalElements = arrayLength(&i420Buffer);
      if (yIndexBytes < bytesPerI420Frame && uIndexBytes < bytesPerI420Frame && vIndexBytes < bytesPerI420Frame && (i420_frame_offset + (vIndexBytes / 4u)) < i420BufferTotalElements) {
        let y_byte = getI420Byte(yIndexBytes, i420_frame_offset, i420BufferTotalElements);
        let u_byte = getI420Byte(uIndexBytes, i420_frame_offset, i420BufferTotalElements);
        let v_byte = getI420Byte(vIndexBytes, i420_frame_offset, i420BufferTotalElements);
        let y_f = f32(y_byte);
        let u_f = f32(u_byte) - 128.0;
        let v_f = f32(v_byte) - 128.0;
        var r_f = y_f + 1.402 * v_f;
        var g_f = y_f - 0.344136 * u_f - 0.714136 * v_f;
        var b_f = y_f + 1.772 * u_f;
        let r = u32(clamp(r_f, 0.0, 255.0)) & 0xFFu;
        let g = u32(clamp(g_f, 0.0, 255.0)) & 0xFFu;
        let b = u32(clamp(b_f, 0.0, 255.0)) & 0xFFu;
        let a = 255u;
        outputPoint.color = (r) | (g << 8u) | (b << 16u) | (a << 24u);
      }
    }
  }
  if (global_output_idx < arrayLength(&xyzColorBuffer)) {
    xyzColorBuffer[global_output_idx] = outputPoint;
  }
}

`;async function Te(e,t,r,m,s,o,p,u,c,l,{hasGPU:f}){var M;const n=e.length;if(n===0||n!==u.length)return console.warn("GPU: Input frame arrays are empty or mismatched."),[];if(t<=0||r<=0)throw new Error("GPU: Invalid depth dimensions!");if(e[0]&&!(e[0]instanceof Uint16Array))throw new Error("GPU: depthFrames[0].data is NOT a Uint16Array!");if(u[0]&&!(u[0]instanceof Uint8Array))throw new Error("GPU: i420Frames[0].data is NOT a Uint8Array!");const i=1;if(!f){const g=[];for(let d=0;d<n;d++){const h=e[d],_=u[d];if(!h||!_){console.warn(`CPU Fallback: Skipping frame ${d} due to missing data.`),g.push(new Uint8Array(0));continue}try{const E=re(h,t,r,m,s,o,p);g.push(te(_,c,l,t,r,E))}catch(E){console.error(`CPU Fallback: Error processing frame ${d}:`,E),g.push(new Uint8Array(0))}}return g}let a=null,y=null,P=null,w=null,S=null,B=null;try{const g=await navigator.gpu.requestAdapter();if(!g)throw new Error("Failed to get GPU adapter.");a=await g.requestDevice();const d=a.queue,h=t*r,_=h*Ce,E=_*n,v=h*2,U=Math.ceil(v/4),fe=U*n*4,k=((M=u[0])==null?void 0:M.byteLength)??0;if(k===0&&n>0)throw new Error("GPU: I420 frame data is empty or invalid for size calculation.");const G=Math.ceil(k/4)*4,ce=G*n,D=new Float32Array([m,s,o,p,i,t,r,c,l,n,k]),de=Math.max(D.byteLength,64);P=a.createBuffer({label:"Intrinsics Buffer",size:de,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),d.writeBuffer(P,0,D.buffer,D.byteOffset,D.byteLength),y=a.createBuffer({label:"Depth Buffer (Combined)",size:fe,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,mappedAtCreation:!0});const me=y.getMappedRange(),T=new Uint32Array(me);for(let b=0;b<n;++b){const x=e[b];if(!x||!(x instanceof Uint16Array)){console.warn(`GPU: Skipping depth frame ${b} due to missing/invalid data.`);const I=b*U,A=U;T.fill(0,I,I+A);continue}const F=b*U;for(let I=0;I<h;I++){const A=x[I]??0,O=F+Math.floor(I/2);if(O>=T.length)continue;I%2===0?T[O]=T[O]&4294901760|A:T[O]=T[O]&65535|A<<16}}y.unmap(),w=a.createBuffer({label:"I420 Buffer (Combined, Aligned)",size:ce,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST,mappedAtCreation:!0});const Z=w.getMappedRange(),K=new Uint8Array(Z);for(let b=0;b<n;++b){const x=u[b],F=b*G;if(!x||!(x instanceof Uint8Array)||x.byteLength!==k){console.warn(`GPU: Skipping I420 frame ${b} due to missing/invalid data or size mismatch.`),K.fill(0,F,F+G);continue}if(new Uint8Array(Z,F,x.byteLength).set(x),G>x.byteLength){const A=F+x.byteLength,O=G-x.byteLength;K.fill(0,A,A+O)}}w.unmap(),S=a.createBuffer({label:"Output XYZColor Buffer (Combined)",size:E,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC}),B=a.createBuffer({label:"Readback Buffer",size:E,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});const J=a.createBindGroupLayout({label:"Compute Bind Group Layout",entries:[{binding:0,visibility:GPUShaderStage.COMPUTE,buffer:{type:"read-only-storage"}},{binding:1,visibility:GPUShaderStage.COMPUTE,buffer:{type:"read-only-storage"}},{binding:2,visibility:GPUShaderStage.COMPUTE,buffer:{type:"storage"}},{binding:3,visibility:GPUShaderStage.COMPUTE,buffer:{type:"read-only-storage"}}]}),pe=a.createBindGroup({label:"Compute Bind Group",layout:J,entries:[{binding:0,resource:{buffer:y}},{binding:1,resource:{buffer:P}},{binding:2,resource:{buffer:S}},{binding:3,resource:{buffer:w}}]}),ye=a.createShaderModule({label:"Compute Shader Module",code:Me}),ge=a.createComputePipeline({label:"Compute Pipeline",layout:a.createPipelineLayout({bindGroupLayouts:[J]}),compute:{module:ye,entryPoint:"main"}}),N=a.createCommandEncoder({label:"Compute Command Encoder"}),R=N.beginComputePass({label:"Compute Pass"});R.setPipeline(ge),R.setBindGroup(0,pe);const he=Math.ceil(h/le),be=n;R.dispatchWorkgroups(he,be,1),R.end(),N.copyBufferToBuffer(S,0,B,0,E),d.submit([N.finish()]),await B.mapAsync(GPUMapMode.READ);const _e=B.getMappedRange(),Q=new Uint8Array(_e.slice(0));B.unmap(),B=null;const X=[];for(let b=0;b<n;b++){const x=b*_,F=Math.min(x+_,Q.byteLength),I=Q.slice(x,F);I.byteLength!==_?(console.warn(`GPU: Result frame ${b} has incorrect size (${I.byteLength} vs ${_}). Padding or error occurred.`),X.push(new Uint8Array(_))):X.push(I)}return X}catch(g){console.error("GPU: Error during WebGPU processing:",g),console.warn("GPU: Falling back to CPU due to error.");const d=[];for(let h=0;h<n;h++){const _=e[h],E=u[h];if(!_||!E){console.warn(`CPU Fallback (error path): Skipping frame ${h} due to missing data.`),d.push(new Uint8Array(0));continue}try{const v=re(_,t,r,m,s,o,p);d.push(te(E,c,l,t,r,v))}catch(v){console.error(`CPU Fallback (error path): Error processing frame ${h}:`,v),d.push(new Uint8Array(0))}}return d}finally{y==null||y.destroy(),P==null||P.destroy(),w==null||w.destroy(),S==null||S.destroy(),B==null||B.destroy()}}j({depthToPointcloudGPU:Te});
