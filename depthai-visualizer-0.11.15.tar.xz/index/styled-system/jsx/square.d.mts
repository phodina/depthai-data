/* eslint-disable */
import type { FunctionComponent } from 'react'
import type { SquareProperties } from '../patterns/square.d.mts';
import type { HTMLStyledProps } from '../types/jsx.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';

export interface SquareProps extends SquareProperties, DistributiveOmit<HTMLStyledProps<'div'>, keyof SquareProperties > {}


export declare const Square: FunctionComponent<SquareProps>