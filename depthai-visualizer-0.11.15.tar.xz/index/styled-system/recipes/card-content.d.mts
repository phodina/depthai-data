/* eslint-disable */
import type { ConditionalValue } from '../types/index.d.mts';
import type { DistributiveOmit, Pretty } from '../types/system-types.d.mts';

interface CardContentVariant {
  
}

type CardContentVariantMap = {
  [key in keyof CardContentVariant]: Array<CardContentVariant[key]>
}

export type CardContentVariantProps = {
  [key in keyof CardContentVariant]?: ConditionalValue<CardContentVariant[key]> | undefined
}

export interface CardContentRecipe {
  __type: CardContentVariantProps
  (props?: CardContentVariantProps): string
  raw: (props?: CardContentVariantProps) => CardContentVariantProps
  variantMap: CardContentVariantMap
  variantKeys: Array<keyof CardContentVariant>
  splitVariantProps<Props extends CardContentVariantProps>(props: Props): [CardContentVariantProps, Pretty<DistributiveOmit<Props, keyof CardContentVariantProps>>]
}

/** Styles for the CardContent component */
export declare const cardContent: CardContentRecipe