/* eslint-disable */
import type { SystemStyleObject, ConditionalValue } from '../types/index.d.mts';
import type { Properties } from '../types/csstype.d.mts';
import type { PropertyValue } from '../types/prop-type.d.mts';
import type { DistributiveOmit } from '../types/system-types.d.mts';
import type { Tokens } from '../tokens/index.d.mts';

export interface LinkBoxProperties {
   
}


interface LinkBoxStyles extends LinkBoxProperties, DistributiveOmit<SystemStyleObject, keyof LinkBoxProperties > {}

interface LinkBoxPatternFn {
  (styles?: LinkBoxStyles): string
  raw: (styles?: LinkBoxStyles) => SystemStyleObject
}


export declare const linkBox: LinkBoxPatternFn;
